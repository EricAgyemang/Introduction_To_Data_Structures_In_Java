public class Stars
{

    private static void drawStars(int n)
    {
        if (n == 0)
            return;
        for (int i = 1; i <= n; i++)
            System.out.print("* ");
        System.out.println();
        drawStars(n - 1);

    }

    private static void printNumbers(int n)
    {
        if (n == 0)
            return;
        printNumbers(n - 1);
        for (int i = 1; i <= n; i++)
            System.out.print(i + "  ");
        System.out.println();
        // printNumbers(n - 1);

    }

    public static void main(String[] args)
    {
        // drawStars(10);
        printNumbers(9);

    }
}
