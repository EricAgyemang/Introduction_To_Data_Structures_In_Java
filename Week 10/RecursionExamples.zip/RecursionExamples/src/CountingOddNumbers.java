public class CountingOddNumbers
{
    static int[] myArr = { 5, 7, 8, 2, 9, 23 };

    static int countOdd(int[] a, int index)
    {
        if (index == a.length - 1)
            return a[index] % 2;
        else
            return a[index] % 2 + countOdd(a, index + 1);

    }

    public static void main(String[] args)
    {
        System.out.println("The nb of odd elements is " + countOdd(myArr, 0));
    }

}
