public class PrintNNumbers
{
    /* printing out first 20 numbers without a loop */
    public static void main(String[] args)
    {

        String[] n = new String[2];

        if (args.length == 0)
            n[1] = "1";
        else
        {
            int x = Integer.parseInt(args[1]) + 1;
            n[1] = new String(Integer.toString(x));
        }
        System.out.print(n[1] + " ");
        if (Integer.parseInt(n[1]) < 20)
            main(n);
    }
}
