public class sumArrayExmple
{

    static int[] myArr = { 5, 7, 8, 2, 9, 23 };

    static int sumArray(int[] a, int index)
    {
        if (index == a.length - 1)
            return a[index];
        else
            return a[index] + sumArray(a, index + 1);

    }

    public static void main(String[] args)
    {
        System.out.println("The sum is: " + sumArray(myArr, 0));
    }

}
