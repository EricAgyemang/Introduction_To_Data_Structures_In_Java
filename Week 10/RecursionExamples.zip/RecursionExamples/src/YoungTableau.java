public class YoungTableau
{
    static int[][] t = { { 6, 7, 8, 99 }, { 8, 17, 87, 456 }, { 61, 77, 89, 699 }, { 68, 94, 99, 899 } };

    static boolean isYoungTableau(int[][] a)
    {
        return true;
    }

    public static void main(String[] args)
    {
        System.out.println(isYoungTableau(t));
        ;

    }

}
