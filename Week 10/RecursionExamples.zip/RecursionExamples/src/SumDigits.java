public class SumDigits
{

    static int sumDigits(int x)
    {
        if (x == 0)
            return 0;
        int y = x % 10;
        int z = x / 10;
        return y + sumDigits(z);
    }

    public static void main(String[] args)
    {
        int n = 658359;
        System.out.println("The sum of the digits of " + n + " is: " + sumDigits(n));

    }
}
