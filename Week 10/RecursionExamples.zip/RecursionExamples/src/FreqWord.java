
public class FreqWord
{

    static String sentence = "Gas is expensive and the weather is nice";

    static int freqOfWord(String[] arrWords, String word, int index)
    {

        if (index == arrWords.length - 1)
            return arrWords[index].equals(word) ? 1 : 0;
        else
            return (arrWords[index].equals(word) ? 1 : 0) + freqOfWord(arrWords, word, index + 1);

    }

    public static void main(String[] args)
    {

        String[] strArr = sentence.split(" ");

        System.out.println("The frequency of (is): " + freqOfWord(strArr, "is", 0));

    }
}
