/**
 * 
 */
package ilstu.edu;

/**
 * @author eagyem2@ilstu.edu
 * 
 * This is the patient class that contains the patient information and
 * it is the super class
 *
 */
public abstract class Patient {

	// We declare the variable of the class
	private int id;
	private String fName;
	private String lName;
	private int age;
	private boolean pcr;

//Constructor for the patient class
	public Patient(int partId, String partFName, String partLName, int partAge) {
		id = partId;
		fName = partFName;
		lName = partLName;
		age = partAge;
	}

	/**
	 * 
	 * Writing the getter Accessors and setter mutators
	 * 
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param setId The setId mutator is declared here
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * The getfName accessor is declared here
	 * 
	 * @return the fName
	 */
	public String getfName() {
		return fName;
	}

	/**
	 * @param fName the setfName mutator is declared here
	 */
	public void setfName(String fName) {
		this.fName = fName;
	}

	/**
	 * @return the lName The getlName accessor is declared here
	 */
	public String getlName() {
		return lName;
	}

	/**
	 * @param lName the setlName mutator is declared here
	 * 
	 */
	public void setlName(String lName) {
		this.lName = lName;
	}

	/**
	 * @return the age The getAge accessor is declared here
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age the setAge mutator is declared here
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return the pcr The isPcr method is delcared here as isPcr(). This method
	 *         returns pcr of a patient
	 * 
	 */
	public boolean isPcr() {
		return pcr;
	}

	/**
	 * @param pcr the
	 * 
	 *            the setPcr mutator is declared here
	 */
	public void setPcr(boolean pcr) {
		this.pcr = pcr;
	}

// Abstract method for the treat() method 
	public abstract String treat();

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

	// Declaring the toString method here
	// The toString method is declared here

	@Override
	public String toString() {

		String result = "Patient [id=" + id + ", Full Name=" + fName + lName + ", age=" + age + ", pcr=" + pcr + "]";

		return result;
	}
}
