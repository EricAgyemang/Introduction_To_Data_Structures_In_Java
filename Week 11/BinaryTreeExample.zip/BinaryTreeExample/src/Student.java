public class Student
{
    private String fName;
    private String lName;
    private double gpa;

    public Student(String fn, String ln, double g)
    {
        fName = fn;
        lName = ln;
        gpa = g;
    }

    public String getFName()
    {
        return fName;
    }

    public String getLName()
    {
        return lName;
    }

    public double getGPA()
    {
        return gpa;
    }

}
