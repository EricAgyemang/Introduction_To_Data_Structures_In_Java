public class Node
{

    private Student std;
    private Node leftChild;
    private Node rightChild;

    public Node(Student s)
    {
        std = s;
        leftChild = null;
        rightChild = null;

    }

    public void printTree(int level)
    {
        // System.out.print("Level = " + level);
        for (int i = 0; i < level; i++)
            System.out.print("    ");

        System.out.println(std.getFName() + " " + std.getLName() + " " + std.getGPA());

        if (leftChild != null)
        {

            // System.out.println("LEFT SUBTREE ");
            leftChild.printTree(level + 1);
        }
        else
        {
            for (int i = 0; i <= level; i++)
                System.out.print("    ");
            System.out.println("NO LEFT CHILD ");
        }
        if (rightChild != null)
        {

            // System.out.println("RIGHT SUBTREE ");
            rightChild.printTree(level + 1);
        }
        else
        {
            for (int i = 0; i <= level; i++)
                System.out.print("    ");
            System.out.println("NO RIGHT CHILD ");
        }
    }

    public void inOrderTraversal()
    {
        if (leftChild != null)
            leftChild.inOrderTraversal();
        System.out.println(std.getFName() + " " + std.getLName() + " " + std.getGPA());
        if (rightChild != null)
            rightChild.inOrderTraversal();
    }

    public void preOrderTraversal()
    {
        System.out.println(std.getFName() + " " + std.getLName() + " " + std.getGPA());
        if (leftChild != null)
            leftChild.preOrderTraversal();

        if (rightChild != null)
            rightChild.preOrderTraversal();
    }

    public void postOrderTraversal()
    {

        if (leftChild != null)
            leftChild.postOrderTraversal();

        if (rightChild != null)
            rightChild.postOrderTraversal();
        System.out.println(std.getFName() + " " + std.getLName() + " " + std.getGPA());
    }

    public void search(String ln)
    {

        if (std.getLName().equals(ln))
            System.out.println("FOUND !!! , GPA = " + std.getGPA());
        if (leftChild != null)
            leftChild.search(ln);

        if (rightChild != null)
            rightChild.search(ln);

        System.out.println("NOT FOUND !!!");
    }

    public void insertChild(Node n)
    {
        if (std.getLName().compareTo(n.std.getLName()) > 0)
            if (leftChild == null)
                leftChild = n;
            else
                leftChild.insertChild(n);
        else if (rightChild == null)
            rightChild = n;
        else
            rightChild.insertChild(n);
    }

}
