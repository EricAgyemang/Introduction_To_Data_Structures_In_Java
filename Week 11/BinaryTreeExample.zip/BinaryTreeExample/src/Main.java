public class Main
{
    static Node root;

    public static void main(String[] args)
    {

        Node[] stdnode = new Node[12];
        stdnode[0] = new Node(new Student("Robert", "Smith", 3.4));
        stdnode[1] = new Node(new Student("Sarah", "Thomas", 3.5));
        stdnode[2] = new Node(new Student("Peter", "Gabby", 3.1));
        stdnode[3] = new Node(new Student("Kyle", "Marcos", 2.1));
        stdnode[4] = new Node(new Student("John", "Havana", 3.3));
        stdnode[5] = new Node(new Student("Cristina", "Robertson", 3.9));
        stdnode[6] = new Node(new Student("David", "Zelensky", 3.4));
        stdnode[7] = new Node(new Student("Philip", "Thomas", 1.8));
        stdnode[8] = new Node(new Student("John", "Dolce", 3.5));
        stdnode[9] = new Node(new Student("Johnathan", "Francisco", 2.7));
        stdnode[10] = new Node(new Student("Brad", "Gabbana", 4.0));
        stdnode[11] = new Node(new Student("Raymond", "Chavez", 2.8));

        root = new Node(new Student("Alex", "Paulson", 2.3));

        for (Node n : stdnode)
            root.insertChild(n);

        root.inOrderTraversal();
        System.out.println("====================");
        root.preOrderTraversal();
        System.out.println("====================");
        root.postOrderTraversal();

        root.search("ASDF");

        // root.printTree(0);

    }
}
